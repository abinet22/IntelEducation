module.exports = {
    HOST: "localhost",
    USER: "admin",
    PASSWORD: "R1445o123/",
    DB: "enteleducation",
  };